import time
import random
from alu import alu
from lmc import lmc, armar_programa
from paralelismo import repartir_trabajo

if __name__ == '__main__':
    print("Prueba ALU (5 + 3):", alu('ADD', 5, 3))
    print("Prueba ALU (5 - 3):", alu('SUB', 5, 3))
    
    print("\nCargando simulador LMC...")
    memoria_prueba = armar_programa()
    
    # Probamos la ejecución del LMC 
    resultado_lmc = lmc(memoria_prueba)
    print(f"LMC listo y ejecutado. Salida: {resultado_lmc}")

    print("\nProbando tiempos con paralelismo")
    lista_ops = ['ADD', 'SUB', 'AND', 'OR', 'XOR', 'SHL']
    datos_prueba = [
        (random.choice(lista_ops), random.randint(0, 100), random.randint(0, 5))
        for _ in range(100000)
    ]
   
    tiempo_uno = 0
    for p in [1, 2, 4]:
        inicio = time.time()
        repartir_trabajo(datos_prueba, p)
        duracion = time.time() - inicio
        
        if p == 1:
            tiempo_uno = duracion
            speedup = 1.0
            eficiencia = 1.0
        else:
            speedup = tiempo_uno / duracion if duracion > 0 else 0
            eficiencia = speedup / p
           
        print(f"Con {p} nucleo(s)  Tarda: {duracion:.4f} segundos | Speedup: {speedup:.2f} | Eficiencia: {eficiencia:.2f}")

    print("\nprograma finalizado")
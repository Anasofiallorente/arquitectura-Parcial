import multiprocessing
from alu import alu


def hacer_trabajo(pedazo):
    return [alu(op, a, b) for op, a, b in pedazo]

def repartir_trabajo(datos, hilos):
    if hilos == 1:
        return hacer_trabajo(datos)
    
    tamanio = len(datos) // hilos
    trozos = [datos[i:i + tamanio] for i in range(0, len(datos), tamanio)]
    
    with multiprocessing.Pool(processes=hilos) as pool:
        resultados = pool.map(hacer_trabajo, trozos)
        
    return [item for sublista in resultados for item in sublista]

def alu(op, a, b):
    # primero definimos el alu y todo lo que se hace en este, cada una de las operaciones logicas
    if op == 'ADD':
        return a + b
    elif op == 'SUB':
        return a - b
    elif op == 'AND':
        return a & b
    elif op == 'OR':
        return a | b
    elif op == 'XOR':
        return a ^ b
    elif op == 'NOT':
        return ~a
    elif op == 'SHL':
        return a << b
    elif op == 'SHR':
        return a >> b
    else:
        return 0
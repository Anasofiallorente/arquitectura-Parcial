
def lmc(memoria):
    pc = 0              # Es el contador de programa Indica en qué número de línea va leyendo el procesador.
    acumulador = 0      # Es un registro temporal donde se guardan los resultados de las operaciones matemáticas .
    salida = []         # Para guardar lo que imprima 
    
    while pc < len(memoria): # recorre la memoria paso a paso
        instruccion = memoria[pc]
        if instruccion == 0:
            pc += 1
            continue
            
        # Separamos la instrucción en código y dirección de memoria
        codigo = instruccion // 100
        dir_mem = instruccion % 100
        pc += 1
        
        if codigo == 1:   # ADD
            acumulador = acumulador + memoria[dir_mem]
        elif codigo == 2: # SUB
            acumulador = acumulador - memoria[dir_mem]
        elif codigo == 3: # STA (guardar)
            memoria[dir_mem] = acumulador
        elif codigo == 5: # LDA (cargar)
            acumulador = memoria[dir_mem]
        elif codigo == 6: # BRA (salto)
            pc = dir_mem
        elif codigo == 7: # BRZ (salto si es cero)
            if acumulador == 0:
                pc = dir_mem
        elif codigo == 9:
            if dir_mem == 22:   # OUT
                salida.append(acumulador)
            elif dir_mem == 0: # HLT (parar)
                break
                
    return salida

def armar_programa():
    # Creamos una memoria de 100 espacios en ceros
    mem = [0] * 100
    mem[90] = 10     # n = 10
    mem[91] = 0      # aquí guardamos la suma
    mem[92] = 1      # el número 1 para restar
    
    # Instrucciones básicas del LMC
    mem[0] = 590     # cargar n
    mem[1] = 707     # si es 0, salta al final
    mem[2] = 191     # sumar al total
    mem[3] = 391     # guardar nuevo total
    mem[4] = 590     # cargar n otra vez
    mem[5] = 292     # restarle 1
    mem[6] = 390     # guardar y repetir
    return mem